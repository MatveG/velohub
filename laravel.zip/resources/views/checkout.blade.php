@extends('layouts.checkout')

@section('content')
    <main role="main" class="content p-5">
        <div id="shop-checkout"></div>
    </main>
@stop
