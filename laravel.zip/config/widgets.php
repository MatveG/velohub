<?php

return [
    'text' => 'App\Widgets\TextWidget',
    'menu' => 'App\Widgets\MenuWidget',
    'catalog' => 'App\Widgets\CatalogWidget',
    'slider' => 'App\Widgets\SliderWidget',
    'cart' => 'App\Widgets\CartWidget',
    'compare' => 'App\Widgets\CompareWidget',
];
