<?php

$loader = require 'vendor/autoload.php';
$loader->add('LucidFrame', __DIR__.'/src/');
