<?php

namespace App\Models\Traits;

use Illuminate\Support\Facades\Storage;

trait ProductImages
{
    public function getImagesAttribute($details)
    {
        return array_map(fn ($url) => Storage::url($url), json_decode($details, true));
    }

    public function setImagesAttribute($value)
    {
        $this->attributes['images'] = json_encode($value);
    }

    public function getImagesStorageAttribute(): string
    {
        return $this->modelName . '/' . $this->category_id . '/';
    }

    public function getThumbAttribute(): ?string
    {
        return (count($this->images)) ? $this->images[0] : null;
    }

    public function getImageAttribute(): ?string
    {
        return (count($this->images)) ? $this->images[0] : null;
    }

//    public function getImagesAttribute(): array
//    {
//        return array_map(fn ($image) => Storage::url($image), json_decode($this->attributes['images']));
//    }
//    public function getThumbsAttribute(): ?array
//    {
//        if (empty($this->images)) {
//            return null;
//        }
//
//        return array_map(function ($item) {
//            return route('img.product', ['img' => str_replace('.jpg', '-md.jpg', $item)]);
//        }, $this->images);
//    }
}
